import dummy from "../db/data.json"

function Day(props) {
  const day = 1;
  const wordList = dummy.words.filter(k=>(k.day) === Number(day))
  return (
    <table>
        <tbody>
           {/* {dummy.words.map(k=>{ */}
           {wordList.map(k=>{
              return <tr key={k.id}>
                     <td>{k.eng}</td>
                     <td>{k.kor}</td>
              </tr>  
           })}
        </tbody>
    </table>
  );
}

export default Day;