import { Link } from "react-router-dom";
import dummy from "../db/data.json"
import "../index.css"
function DayList(props) {
  //  console.log(dummy);
  return (
    <ul className="list_day">
      {dummy.days.map(k=>{
       return <li key={k.id}>
              <Link to={"/day"}> Day{k.day} </Link>
              </li>
      })}
    </ul>
  );
}

export default DayList;